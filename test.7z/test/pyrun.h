#ifndef PYRUN_H
#define PYRUN_H
#include <QString>
#include <QStringList>

namespace PyRun
{
enum State
{
    PythonUninitialized,
    PythonInitialized,
    AppModuleLoaded
};
enum Resultado
{
    CannotLoadModule,
    CannotConvertArgument,
    CallFailed,
    CannotFindFunction,
    FailedToLoad,
    Success
};

int loadModule(const QString &moduleName, const QString &functionName, const QStringList &args);
State init();
}
#endif // PYRUN_H
