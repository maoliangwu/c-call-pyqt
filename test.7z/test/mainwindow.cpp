#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "./pyrun.h"
#include <QDebug>
#include <QDir>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //QString pModulo = "hellopyqt";//failed
    QString pModulo = "test";
    QString pFuncion = "fun";
    QStringList pArgumentos;
    pArgumentos<<"1"<<"2"<<"3"<<"4";
    int res = ::PyRun::loadModule(pModulo, pFuncion, pArgumentos);
    qDebug()<<"Resultado: "<<res;
}

MainWindow::~MainWindow()
{
    delete ui;
}

