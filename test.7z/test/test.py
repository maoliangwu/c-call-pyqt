def fun():
    print("Something that provides mirth or amusement")